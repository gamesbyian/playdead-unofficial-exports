#include <stdio.h>
#include <stdint.h>
 

int copy(char* a, int length)
{	
	int i;
	memcpy(&i, a, length);
	return i;
}


void main() 
{
	FILE *fp;
	long lSize;
	char *buffer;

	fp = fopen ( "data.dat" , "rb" );
	if( !fp ) perror("data.dat"),exit(1);

	fseek( fp , 0L , SEEK_END);
	lSize = ftell( fp );
	rewind( fp );

	/* allocate memory for entire content */
	buffer = calloc( 1, lSize+1 );
	if( !buffer ) 
		fclose(fp),fputs("memory alloc fails",stderr),exit(1);

	/* copy the file into the buffer */
	if( 1!=fread( buffer , lSize, 1 , fp) )
	  fclose(fp),free(buffer),fputs("entire read fails",stderr),exit(1);

	struct fileData
	{
		char formatA;
		char formatB;
		uint32_t size;
		uint32_t nothing;
		uint32_t offset;		
		uint32_t headerSize;
		uint32_t width;
		uint32_t height;	
		uint16_t  planes;
		uint16_t  bpp;
		uint32_t comp;
		uint32_t compSize;
		uint32_t PPMW;
		uint32_t PPMH;
		uint32_t colorsUsed;
		uint32_t important;
		
	};
	struct fileData fileDataValue;
	
	fileDataValue.formatA = 'B';
	fileDataValue.formatB = 'M';
	fileDataValue.size = lSize + 54 - 2;
	fileDataValue.offset = 54;
	fileDataValue.headerSize = 40;
	fileDataValue.width = 41;
	fileDataValue.height = 41;	
	fileDataValue.planes = 1;
	fileDataValue.bpp = 24;
	fileDataValue.comp = 0;
	fileDataValue.compSize = 0;
	fileDataValue.PPMW = 72;
	fileDataValue.PPMH = 72;
	fileDataValue.colorsUsed = 256;
	fileDataValue.important = 0;
		
	FILE * file= fopen("output.bmp", "wb");
	if (file != NULL) 
	{
		fwrite(&fileDataValue, 54, 1, file);
		for(int index = 2; index < lSize; index++)			
			fwrite(&buffer[2], lSize - 2, 1, file);			
		
		fclose(file);
	}
	
	

	fclose(fp);
	free(buffer);


	return 0;
}


